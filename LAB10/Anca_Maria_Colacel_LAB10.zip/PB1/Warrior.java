package PB1;

public class Warrior extends Hero{
    @Override
    void execute() {
        super.execute();
    }
}
