package PB1;

abstract class Hero {
    void execute(){
        System.out.println("Hero");
    }
}
