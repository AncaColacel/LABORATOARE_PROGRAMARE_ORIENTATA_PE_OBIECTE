package PB1;

public class Rogue extends Hero{
    @Override
    void execute() {
        System.out.println("Rogue");
    }
}
