package PB1;

public class Ninja extends Hero{
    @Override
    void execute() {
        System.out.println("Ninja");
    }
}
