package LAB1;

public class Problema3_2 {
    public void print(String s){
        System.out.println(s);
    }
}
