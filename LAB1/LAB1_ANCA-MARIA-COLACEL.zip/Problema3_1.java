package LAB1;

public class Problema3_1 {
    public static void main(String[] args) {
        Problema3_2 problema3_2 = new Problema3_2();
        problema3_2.print("ana");
    }
}
