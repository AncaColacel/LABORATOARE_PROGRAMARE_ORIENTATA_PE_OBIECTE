package LAB1;
//
    public class Problema2 {
          public static void main(String[] args) {
             // creare obiect de tipul clasei Problema2
             Problema2 obiect = new Problema2();
              // apelare functie print cu argumentul test
             obiect.print("Anca");
        }
        public void print (String text) {

              System.out.println(text);
        }

    }