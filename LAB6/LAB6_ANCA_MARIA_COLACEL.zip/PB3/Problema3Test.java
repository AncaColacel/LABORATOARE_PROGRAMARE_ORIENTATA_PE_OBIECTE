package PB3;

import java.util.Collections;
import java.util.Vector;

public class Problema3Test {
    public static void main(String[] args) {
        Vector<Student> studenti = new Vector<>();
        Student s1 = new Student();
        s1.setNume("Ana");
        s1.addMedie(7);
        s1.addMedie(9);
        studenti.add(s1);
        Student s2 = new Student();
        s2.setNume("Ana");
        s2.addMedie(8);
        s2.addMedie(10);
        studenti.add(s2);
        Student s3 = new Student();
        s3.setNume("Vlad");
        s3.addMedie(6);
        s3.addMedie(10);
        studenti.add(s3);
        // in spate, Collection.sort va apela metoda mea de compareTo si va folosi criteriile
        // impuse de mine, anume lexicografic dupa nume si daca numele este la fel
        // va fi printat cel cu media cea mai mare
        Collections.sort(studenti);
        for (int i = 0; i < studenti.size(); i++) {
            System.out.println(studenti.get(i));
        }

    }

}