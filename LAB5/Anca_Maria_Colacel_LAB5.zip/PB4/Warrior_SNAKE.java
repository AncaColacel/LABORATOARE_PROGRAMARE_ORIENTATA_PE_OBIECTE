package PB4;

public class Warrior_SNAKE extends Warrior {
    private final int damage = 10;

    public Warrior_SNAKE (int health, String name) {
        super (health, name);
    }

    public int getDamage_SNAKE () {
        return damage;
    }

}
