package PB4;

public class Warrior_MARSHMALLOW_MAN extends Warrior {
    private int damage = 1;

    public Warrior_MARSHMALLOW_MAN (int health, String name) {
        super (health, name);
    }

    public int getDamage_MARSHMALLOW_MAN () {
        return damage;
    }
}
