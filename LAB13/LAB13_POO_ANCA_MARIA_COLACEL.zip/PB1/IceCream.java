package PB1;

public interface IceCream {
    public String getDescription ();
    public double getPrice ();

}
